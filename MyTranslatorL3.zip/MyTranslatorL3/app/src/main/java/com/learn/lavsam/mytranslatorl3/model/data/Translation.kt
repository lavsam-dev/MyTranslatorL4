package com.learn.lavsam.mytranslatorl3.model.data

import com.google.gson.annotations.SerializedName

class Translation(@field:SerializedName("text") val translation: String?)
