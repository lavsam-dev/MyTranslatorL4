package com.learn.lavsam.mytranslatorl3.di

internal const val NAME_REMOTE = "Remote"
internal const val NAME_LOCAL = "Local"