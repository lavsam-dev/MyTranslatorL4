package com.learn.lavsam.mytranslatorl3.utils

fun String.Companion.getEmptyString(): String = ""